from datetime import datetime

from movienight.db.models import Proposal, User
from movienight.schemas.home import ProposalCard
from movienight.services.home_card_state import (
    build_card_flags,
    is_winner,
    normalize_card_times,
)


def map_card(
    proposal: Proposal,
    component: list[Proposal],
    component_vote_counts: dict[int, int],
    votes_count: int,
    my_vote: bool,
    reactions: dict[str, int],
    my_reactions: list[str],
    current_user: User,
    now: datetime,
    winner_id: int | None,
) -> ProposalCard:
    starts_at, ends_at, created_at, normalized_now = normalize_card_times(
        proposal=proposal,
        now=now,
    )
    flags = build_card_flags(
        proposal=proposal,
        current_user=current_user,
        my_vote=my_vote,
        starts_at=starts_at,
        component=component,
        component_vote_counts=component_vote_counts,
        reactions=reactions,
        my_reactions=my_reactions,
        now=normalized_now,
    )

    return ProposalCard(
        id=proposal.id,
        movie_title=proposal.movie_title,
        room=proposal.room,
        starts_at=starts_at,
        ends_at=ends_at,
        created_at=created_at,
        created_by=proposal.creator.username,
        votes_count=votes_count,
        my_vote=my_vote,
        my_reactions=flags["visible_my_reactions"],
        reactions=flags["visible_reactions"],
        show_reactions=flags["reaction_block_active"],
        is_past=flags["is_past"],
        is_winner=is_winner(proposal.id, winner_id),
        can_vote=flags["can_vote"],
        can_unvote=flags["can_unvote"],
        can_delete=flags["can_delete"],
        can_add_reaction=flags["can_add_reaction"],
        can_remove_reaction=flags["can_remove_reaction"],
    )
