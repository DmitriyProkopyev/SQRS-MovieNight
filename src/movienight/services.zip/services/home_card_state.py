from datetime import datetime

from movienight.core.clock import as_utc
from movienight.db.models import Proposal, User
from movienight.services.schedule_rules import is_in_past, is_vote_locked
from movienight.services.voting_rules import is_reaction_target


def normalize_card_times(
    proposal: Proposal,
    now: datetime,
) -> tuple[datetime, datetime, datetime, datetime]:
    return (
        as_utc(proposal.starts_at),
        as_utc(proposal.ends_at),
        as_utc(proposal.created_at),
        as_utc(now),
    )


def build_vote_state(
    proposal: Proposal,
    current_user: User,
    my_vote: bool,
    vote_locked: bool,
    is_past: bool,
) -> dict[str, bool]:
    is_owner = proposal.creator_id == current_user.id

    return {
        "can_vote": not any((my_vote, is_owner, vote_locked, is_past)),
        "can_unvote": my_vote and not vote_locked and not is_past,
        "can_delete": is_owner and not is_past,
    }


def build_reaction_state(
    proposal: Proposal,
    component: list[Proposal],
    component_vote_counts: dict[int, int],
    reactions: dict[str, int],
    my_reactions: list[str],
    now: datetime,
) -> dict:
    reaction_block_active = is_reaction_target(
        proposal=proposal,
        component=component,
        vote_counts=component_vote_counts,
        now=now,
    )

    if reaction_block_active:
        visible_reactions: dict[str, int] | None = reactions
        visible_my_reactions = my_reactions
    else:
        visible_reactions = None
        visible_my_reactions = []

    return {
        "reaction_block_active": reaction_block_active,
        "visible_reactions": visible_reactions,
        "visible_my_reactions": visible_my_reactions,
        "can_add_reaction": reaction_block_active,
        "can_remove_reaction": (
            reaction_block_active and bool(my_reactions)
        ),
    }


def build_card_flags(
    proposal: Proposal,
    current_user: User,
    my_vote: bool,
    starts_at: datetime,
    component: list[Proposal],
    component_vote_counts: dict[int, int],
    reactions: dict[str, int],
    my_reactions: list[str],
    now: datetime,
) -> dict:
    is_past = is_in_past(starts_at, now)
    vote_locked = is_vote_locked(starts_at, now)

    vote_state = build_vote_state(
        proposal=proposal,
        current_user=current_user,
        my_vote=my_vote,
        vote_locked=vote_locked,
        is_past=is_past,
    )
    reaction_state = build_reaction_state(
        proposal=proposal,
        component=component,
        component_vote_counts=component_vote_counts,
        reactions=reactions,
        my_reactions=my_reactions,
        now=now,
    )

    return {
        "is_past": is_past,
        "vote_locked": vote_locked,
        **vote_state,
        **reaction_state,
    }


def is_winner(proposal_id: int, winner_id: int | None) -> bool:
    return winner_id is not None and winner_id == proposal_id
