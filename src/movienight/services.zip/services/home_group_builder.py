from datetime import datetime

from movienight.db.models import Proposal, User
from movienight.schemas.home import ProposalGroup
from movienight.services.home_group_mapper import map_group
from movienight.services.voting_rules import build_conflict_component


def build_home_groups(
    proposals: list[Proposal],
    vote_counts: dict[int, int],
    reaction_counts: dict[int, dict[str, int]],
    my_reactions_map: dict[int, list[str]],
    my_votes: set[int],
    current_user: User,
    now: datetime,
) -> list[ProposalGroup]:
    groups: list[ProposalGroup] = []
    visited: set[int] = set()

    for proposal in proposals:
        if proposal.id in visited:
            continue

        component = build_conflict_component(
            proposal,
            room_proposals(proposals, proposal.room),
        )
        visited.update(item.id for item in component)

        groups.append(
            map_group(
                component=component,
                vote_counts=vote_counts,
                reaction_counts=reaction_counts,
                my_reactions_map=my_reactions_map,
                my_votes=my_votes,
                current_user=current_user,
                now=now,
            )
        )

    groups.sort(key=lambda group: (group.starts_at, group.room))
    return groups


def room_proposals(
    proposals: list[Proposal],
    room: str,
) -> list[Proposal]:
    return [item for item in proposals if item.room == room]
