from datetime import datetime

from movienight.db.models import Proposal, User
from movienight.schemas.home import ProposalGroup
from movienight.services.home_card_mapper import map_card
from movienight.services.home_group_meta import (
    build_component_vote_counts,
    build_group_window,
    build_winner_id,
)
from movienight.services.schedule_rules import is_vote_locked
from movienight.services.voting_rules import choose_winner


def map_group(
    component: list[Proposal],
    vote_counts: dict[int, int],
    reaction_counts: dict[int, dict[str, int]],
    my_reactions_map: dict[int, list[str]],
    my_votes: set[int],
    current_user: User,
    now: datetime,
) -> ProposalGroup:
    winner = choose_winner(component, vote_counts) if component else None
    winner_id = build_winner_id(
        component=component,
        winner=winner,
        now=now,
    )
    component_vote_counts = build_component_vote_counts(
        component=component,
        vote_counts=vote_counts,
    )
    starts_at, ends_at = build_group_window(component)

    cards = [
        map_card(
            proposal=item,
            component=component,
            component_vote_counts=component_vote_counts,
            votes_count=vote_counts.get(item.id, 0),
            my_vote=item.id in my_votes,
            reactions=reaction_counts.get(item.id, {}),
            my_reactions=my_reactions_map.get(item.id, []),
            current_user=current_user,
            now=now,
            winner_id=winner_id,
        )
        for item in component
    ]

    return ProposalGroup(
        room=component[0].room,
        starts_at=starts_at,
        ends_at=ends_at,
        is_conflict=len(component) > 1,
        is_locked=is_vote_locked(starts_at, now),
        winner_proposal_id=winner_id,
        proposals=cards,
    )
