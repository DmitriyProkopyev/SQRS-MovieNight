from datetime import datetime

from movienight.core.clock import as_utc
from movienight.db.models import Proposal
from movienight.services.schedule_rules import is_vote_locked


def build_group_window(
    component: list[Proposal],
) -> tuple[datetime, datetime]:
    starts_at = min(as_utc(item.starts_at) for item in component)
    ends_at = max(as_utc(item.ends_at) for item in component)
    return starts_at, ends_at


def build_winner_id(
    component: list[Proposal],
    winner: Proposal | None,
    now: datetime,
) -> int | None:
    if not winner:
        return None

    group_starts_at, _ = build_group_window(component)
    group_is_locked = is_vote_locked(group_starts_at, now)
    should_show_winner = len(component) > 1 and group_is_locked

    if should_show_winner:
        return winner.id
    return None


def build_component_vote_counts(
    component: list[Proposal],
    vote_counts: dict[int, int],
) -> dict[int, int]:
    return {
        item.id: vote_counts.get(item.id, 0)
        for item in component
    }
